// ============================================================
// FILE: E:\sm-core\ui-text.js
// PURPOSE: Texteditor (Overlay) – SM Core v0003
// OWNER: Sandamicke
// ============================================================

let currentEditingFileName = null;
let creatingNewFile = false;

// Öppna editor för NY fil
window.createNewTextFile = function () {
    const box = document.getElementById("noteEditorBox");
    const area = document.getElementById("noteEditorArea");

    if (!box || !area) return;

    creatingNewFile = true;
    currentEditingFileName = null;

    area.value = "";
    box.style.display = "block";
};

// Öppna befintlig textfil för redigering
window.editTextFile = async function (url, fileName) {
    try {
        const res = await fetch(url + "?t=" + Date.now());
        const text = await res.text();

        const box = document.getElementById("noteEditorBox");
        const area = document.getElementById("noteEditorArea");

        if (!box || !area) {
            alert("Texteditor saknas i HTML.");
            return;
        }

        creatingNewFile = false;
        currentEditingFileName = fileName;

        area.value = text;
        box.style.display = "block";

    } catch (err) {
        console.error("Kunde inte läsa textfil:", err);
        alert("Kunde inte läsa textfilen.");
    }
};

// Spara (ny eller befintlig)
window.saveTextFile = async function () {
    const area = document.getElementById("noteEditorArea");
    if (!area) return;

    const text = area.value;

    if (!currentJob || !currentJob.id) {
        alert("Jobb saknas.");
        return;
    }

    try {
        let res;

        if (creatingNewFile) {
            res = await fetch("/api/files/createText", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    tenantId: TENANT,
                    jobId: currentJob.id,
                    content: text
                })
            });
        } else {
            res = await fetch("/api/files/updateText", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    tenantId: TENANT,
                    jobId: currentJob.id,
                    fileName: currentEditingFileName,
                    content: text
                })
            });
        }

        const data = await res.json().catch(() => ({ success: false }));

        if (!data.success) {
            alert("Kunde inte spara textfilen.");
            return;
        }

        const box = document.getElementById("noteEditorBox");
        if (box) box.style.display = "none";

        if (window.lastPreviewedFile) {
            previewFile(window.lastPreviewedFile);
        }

        await loadJob();

        creatingNewFile = false;
        currentEditingFileName = null;

    } catch (err) {
        console.error("Fel vid saveTextFile:", err);
        alert("Fel vid sparning.");
    }
};

// Stäng editor
window.closeTextEditor = function () {
    const box = document.getElementById("noteEditorBox");
    if (box) box.style.display = "none";

    creatingNewFile = false;
    currentEditingFileName = null;
};
