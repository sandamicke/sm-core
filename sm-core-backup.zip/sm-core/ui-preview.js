// ============================================================
// FILE: E:\sm-core\ui-preview.js
// PURPOSE: Förhandsvisning (Modul) + Mobil overlay-preview
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

var lastPreviewedFile = window.lastPreviewedFile || null;

// ============================================================
// MOBIL OVERLAY – DETEKTION (JUSTerad FÖR EDGE-MOBILTEST)
// ============================================================

function isMobile() {
    const ua = navigator.userAgent || navigator.vendor || window.opera;

    const isDesktopOS =
        /windows nt/i.test(ua) ||
        /macintosh/i.test(ua) ||
        /linux/i.test(ua) ||
        /cros/i.test(ua);

    // Desktop blockeras ENDAST om fönstret är större än 600px
    if (isDesktopOS && window.innerWidth > 600) return false;

    // ⭐ Tillåt mobil-läge i smalt fönster (Edge-demo)
    if (window.innerWidth <= 600) return true;

    const realMobile =
        /android/i.test(ua) ||
        /iphone/i.test(ua) ||
        /ipad/i.test(ua) ||
        /ipod/i.test(ua);

    if (realMobile) return true;

    const touch = navigator.maxTouchPoints > 1;
    const mq = window.matchMedia("(max-width: 600px)").matches;

    return touch && mq;
}

function openMobileOverlay(html) {
    const overlay = document.getElementById("mobilePreviewOverlay");
    const content = document.getElementById("mobilePreviewContent");
    if (!overlay || !content) return;

    content.innerHTML = html;
    overlay.classList.remove("hidden");
    document.body.style.overflow = "hidden";
}

function closeMobileOverlay() {
    const overlay = document.getElementById("mobilePreviewOverlay");
    const content = document.getElementById("mobilePreviewContent");
    if (!overlay || !content) return;

    content.innerHTML = "";
    overlay.classList.add("hidden");
    document.body.style.overflow = "";
}

window.closeMobileOverlay = closeMobileOverlay;

// ============================================================
// Knappar (Word/Excel/Default)
// ============================================================

function hidePreviewButtons() {
    const ids = ["openWordBtn", "openExcelBtn", "openDefaultBtn"];
    ids.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) btn.style.display = "none";
    });
}

function updatePreviewButtons(file) {
    if (!file || !file.originalName) {
        hidePreviewButtons();
        return;
    }

    hidePreviewButtons();

    const lower = file.originalName.toLowerCase();

    const wordBtn = document.getElementById("openWordBtn");
    const excelBtn = document.getElementById("openExcelBtn");
    const defaultBtn = document.getElementById("openDefaultBtn");

    if (lower.endsWith(".doc") || lower.endsWith(".docx")) {
        if (wordBtn) {
            wordBtn.style.display = "inline-block";
            wordBtn.onclick = () => openInWord(file);
        }
        return;
    }

    if (lower.endsWith(".xls") || lower.endsWith(".xlsx")) {
        if (excelBtn) {
            excelBtn.style.display = "inline-block";
            excelBtn.onclick = () => openInExcel(file);
        }
        return;
    }

    if (defaultBtn) {
        defaultBtn.style.display = "inline-block";
        defaultBtn.onclick = () => downloadAndOpen(file);
    }
}

// ============================================================
// Rensa preview
// ============================================================

function clearPreview() {
    const box = document.getElementById("previewArea");
    if (!box) return;

    hidePreviewButtons();

    box.innerHTML = "";
    box.classList.add("empty");
    lastPreviewedFile = null;
    window.lastPreviewedFile = null;
}

// ============================================================
// ⭐ Klick‑zoom (toggle)
// ============================================================

let previewZoomed = false;

function enableClickZoom(img) {
    if (!img) return;

    img.style.transition = "transform 0.2s ease";
    img.style.cursor = "zoom-in";

    img.onclick = () => {
        previewZoomed = !previewZoomed;

        if (previewZoomed) {
            img.style.transform = "scale(2)";
            img.style.cursor = "zoom-out";
        } else {
            img.style.transform = "scale(1)";
            img.style.cursor = "zoom-in";
        }
    };
}

// ============================================================
// ⭐ Render-helper: Desktop eller Mobil?
// ============================================================

function renderPreview(html) {
    if (isMobile()) {
        openMobileOverlay(html);
    } else {
        const box = document.getElementById("previewArea");
        if (!box) return;
        box.innerHTML = html;
        box.classList.remove("empty");
    }
}

// ============================================================
// Förhandsvisning av filer
// ============================================================

async function previewFile(file) {
    const box = document.getElementById("previewArea");
    if (!box || !file) return;

    const url = `/files/raw/${file.filename}`;
    file.url = url;

    lastPreviewedFile = file;
    window.lastPreviewedFile = file;

    updatePreviewButtons(file);

    if (!isMobile()) {
        box.classList.remove("empty");
        box.innerHTML = "Laddar...";
    }

    const lowerUrl = url.toLowerCase();

    if (lowerUrl.endsWith(".pdf")) {
        renderPreview(`
            <embed src="${url}" type="application/pdf" style="width:100%; height:100%; border:none;" />
        `);
        return;
    }

    if (lowerUrl.endsWith(".docx")) {
        try {
            const response = await fetch(url);
            const arrayBuffer = await response.arrayBuffer();
            const result = await mammoth.convertToHtml({ arrayBuffer });

            renderPreview(`
                <div style="background:white; color:black; padding:20px; border-radius:6px; max-width:100%; max-height:100%; overflow:auto;">
                    ${result.value}
                </div>
            `);
        } catch {
            renderPreview("Kunde inte läsa DOCX-filen.");
        }
        return;
    }

    if (lowerUrl.endsWith(".xlsx") || lowerUrl.endsWith(".xls")) {
        try {
            const response = await fetch(url);
            const arrayBuffer = await response.arrayBuffer();
            const workbook = XLSX.read(arrayBuffer, { type: "array" });

            let html = "";
            workbook.SheetNames.forEach(sheetName => {
                const sheet = workbook.Sheets[sheetName];
                html += `
                    <h3 style="margin-top:20px;">${sheetName}</h3>
                    ${XLSX.utils.sheet_to_html(sheet)}
                `;
            });

            renderPreview(`
                <div style="background:white; color:black; padding:20px; border-radius:6px; max-width:100%; max-height:100%; overflow:auto;">
                    ${html}
                </div>
            `);
        } catch {
            renderPreview("Kunde inte läsa Excel-filen.");
        }
        return;
    }

    if (/\.(jpg|jpeg|png|gif|webp)$/i.test(lowerUrl)) {
        const html = `<img id="previewImage" src="${url}" style="max-width:100%; max-height:100%; border-radius:6px;" />`;

        renderPreview(html);

        if (!isMobile()) {
            enableClickZoom(document.getElementById("previewImage"));
        }
        return;
    }

    if (lowerUrl.endsWith(".txt") || lowerUrl.endsWith(".csv") || lowerUrl.endsWith(".log") || lowerUrl.endsWith(".md")) {
        try {
            const response = await fetch(url);
            const text = await response.text();

            renderPreview(`
                <pre style="white-space:pre-wrap; background:white; color:black; padding:20px; border-radius:6px; max-width:100%; max-height:100%; overflow:auto;">
${text}
                </pre>
            `);
        } catch {
            renderPreview("Kunde inte läsa textfilen.");
        }
        return;
    }

    renderPreview(`
        <p>Kan inte förhandsvisa denna filtyp.</p>
        <p><strong>${file.originalName || "Okänd fil"}</strong></p>
    `);
}

window.previewFile = previewFile;
window.clearPreview = clearPreview;
