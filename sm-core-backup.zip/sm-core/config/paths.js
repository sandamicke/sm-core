// ============================================================
// FILE: E:\sm-core\config\paths.js
// PURPOSE: Central path configuration
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: This header is grep-friendly and must remain intact.
// ============================================================

const path = require("path");

// ------------------------------------------------------------
// ROOT = projektroten
// __dirname pekar på: E:\sm-core\config\
// ------------------------------------------------------------
const ROOT = path.resolve(__dirname, "..");

// ------------------------------------------------------------
// DATA_ROOT = datalagring inne i projektet (v0003 default)
// ------------------------------------------------------------
const DATA_ROOT = path.join(ROOT, "data");

// ------------------------------------------------------------
// TENANTS_ROOT = alla tenants lever här
// ------------------------------------------------------------
const TENANTS_ROOT = path.join(DATA_ROOT, "tenants");

// ------------------------------------------------------------
// tenantPaths(tenantId)
// Bygger alla paths för en tenant
// ------------------------------------------------------------
function tenantPaths(tenantId) {
    if (!tenantId || typeof tenantId !== "string") {
        throw new Error("tenantId krävs i tenantPaths()");
    }

    const base = path.join(TENANTS_ROOT, tenantId);

    return {
        base,
        projectFile: path.join(base, "project.json"),
        historyDir: path.join(base, "history"),
        filesDir: path.join(base, "files"),
        rawDir: path.join(base, "files", "raw") // v0003: tydlig råfilskatalog
    };
}

module.exports = {
    ROOT,
    DATA_ROOT,
    TENANTS_ROOT,
    tenantPaths
};
