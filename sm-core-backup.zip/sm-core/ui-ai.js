// ============================================================
// FILE: E:\sm-core\ui-ai.js
// PURPOSE: AI-system (Modul)
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

document.addEventListener("DOMContentLoaded", () => {
    const btn = document.getElementById("aiRunBtn");
    if (btn) btn.onclick = runAICommand;
});

/* ============================================================
   TEXTEXTRAKTION
   ============================================================ */

async function extractTextForAI(file) {
    if (!file || !file.url) return "Ingen fil vald.";

    const url = file.url.toLowerCase();

    // TEXT / CSV / LOG / JSON
    if (url.endsWith(".txt") || url.endsWith(".csv") || url.endsWith(".log") || url.endsWith(".json")) {
        try {
            const res = await fetch(file.url);
            return await res.text();
        } catch {
            return "Kunde inte läsa textfilen.";
        }
    }

    // DOCX – Mammoth
    if (url.endsWith(".docx")) {
        if (typeof mammoth === "undefined") {
            return "DOCX-stöd saknas.";
        }

        try {
            const response = await fetch(file.url);
            const arrayBuffer = await response.arrayBuffer();
            const result = await mammoth.convertToHtml({ arrayBuffer });

            const tmp = document.createElement("div");
            tmp.innerHTML = result.value || "";
            return tmp.textContent || tmp.innerText || "";
        } catch {
            return "Kunde inte extrahera text ur DOCX-filen.";
        }
    }

    // XLS / XLSX – SheetJS
    if (url.endsWith(".xlsx") || url.endsWith(".xls")) {
        if (typeof XLSX === "undefined") {
            return "Excel-stöd saknas.";
        }

        try {
            const response = await fetch(file.url);
            const arrayBuffer = await response.arrayBuffer();
            const workbook = XLSX.read(arrayBuffer, { type: "array" });

            const sheetName = workbook.SheetNames[0];
            if (!sheetName) return "Inga ark hittades.";

            const sheet = workbook.Sheets[sheetName];
            return XLSX.utils.sheet_to_csv(sheet);
        } catch {
            return "Kunde inte extrahera text ur Excel-filen.";
        }
    }

    // PDF – PDF.js
    if (url.endsWith(".pdf")) {
        if (typeof pdfjsLib === "undefined") {
            return "PDF-textutdrag är inte aktiverat.";
        }

        try {
            const loadingTask = pdfjsLib.getDocument(file.url);
            const pdf = await loadingTask.promise;

            let fullText = "";
            const maxPages = Math.min(pdf.numPages, 3);

            for (let i = 1; i <= maxPages; i++) {
                const page = await pdf.getPage(i);
                const content = await page.getTextContent();
                fullText += content.items.map(x => x.str).join(" ") + "\n\n";
            }

            return fullText;
        } catch {
            return "Kunde inte extrahera text ur PDF.";
        }
    }

    return "Denna filtyp stöds inte för AI.";
}

/* ============================================================
   HUVUDFUNKTION – KÖR AI-KOMMANDO
   ============================================================ */

async function runAICommand() {
    const input = document.getElementById("aiCommand");
    const results = document.getElementById("aiResults");

    if (!input || !results) return;

    const command = input.value.trim();
    if (!command) {
        alert("Skriv ett AI-kommando först.");
        return;
    }

    if (!lastPreviewedFile) {
        alert("Välj en fil först.");
        return;
    }

    let text = "";
    try {
        text = await extractTextForAI(lastPreviewedFile);
    } catch {
        alert("Kunde inte läsa filen.");
        return;
    }

    const aiOutput =
        `AI-kommando: ${command}\n` +
        `Fil: ${lastPreviewedFile.originalName}\n\n` +
        `=== AI-RESULTAT ===\n\n` +
        generateAISummary(text, command);

    const aiFileName = `AI_${Date.now()}.txt`;

    aiFiles.unshift({
        name: aiFileName,
        content: aiOutput
    });

    renderAIResults();
    input.value = "";
}

/* ============================================================
   AI-SUMMARY
   ============================================================ */

function generateAISummary(text, command) {
    const lines = (text || "").split("\n").slice(0, 20);
    const shortText = lines.join("\n");

    return (
        `Kommando: ${command}\n\n` +
        `Utdrag:\n-------------------------\n` +
        shortText +
        `\n-------------------------\n\n` +
        `AI-kommentar:\nDetta är en kompakt bearbetning.`
    );
}

/* ============================================================
   RENDERING AV AI-FILER
   ============================================================ */

function renderAIResults() {
    const results = document.getElementById("aiResults");
    if (!results) return;

    results.innerHTML = "";

    aiFiles.forEach((file, index) => {
        if (!file) return;

        const row = document.createElement("div");
        row.className = "ai-file-row";

        const nameSpan = document.createElement("span");
        nameSpan.className = "ai-file-name";
        nameSpan.textContent = file.name;
        nameSpan.style.cursor = "pointer";
        nameSpan.onclick = () => previewAIFile(index);

        const btnContainer = document.createElement("div");
        btnContainer.className = "ai-file-actions";

        const btnView = document.createElement("button");
        btnView.className = "file-btn";
        btnView.textContent = "Visa";
        btnView.onclick = () => previewAIFile(index);

        const btnOpen = document.createElement("button");
        btnOpen.className = "file-btn";
        btnOpen.textContent = "Öppna";
        btnOpen.onclick = () => openAIFile(index);

        const btnDelete = document.createElement("button");
        btnDelete.className = "file-btn file-btn-danger";
        btnDelete.textContent = "Ta bort";
        btnDelete.onclick = () => deleteAIFile(index);

        btnContainer.appendChild(btnView);
        btnContainer.appendChild(btnOpen);
        btnContainer.appendChild(btnDelete);

        row.appendChild(nameSpan);
        row.appendChild(btnContainer);

        results.appendChild(row);
    });
}

/* ============================================================
   FÖRHANDSVISNING AV AI-FIL
   ============================================================ */

function previewAIFile(index) {
    const file = aiFiles[index];
    if (!file) return;

    const box = document.getElementById("previewArea");
    if (!box) return;

    hidePreviewButtons();

    box.classList.remove("empty");
    box.innerHTML = `
        <pre style="white-space:pre-wrap; background:white; color:black; padding:20px; border-radius:6px;">
${file.content}
        </pre>
    `;
}

/* ============================================================
   ÖPPNA AI-FIL
   ============================================================ */

function openAIFile(index) {
    const file = aiFiles[index];
    if (!file) return;

    const blob = new Blob([file.content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank");
}

/* ============================================================
   TA BORT AI-FIL
   ============================================================ */

function deleteAIFile(index) {
    if (index < 0 || index >= aiFiles.length) return;
    aiFiles.splice(index, 1);
    renderAIResults();
}
