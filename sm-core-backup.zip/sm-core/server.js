// ============================================================
// FILE: E:\sm-core\server.js
// PURPOSE: Main server för SM Core
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const express = require("express");
const path = require("path");
const app = express();

// ------------------------------------------------------------
// 1) STATIC FILES – MÅSTE KOMMA FÖRST
// ------------------------------------------------------------
app.use(express.static(__dirname, {
    etag: false,
    maxAge: 0,
    cacheControl: false,
    immutable: false
}));

// ------------------------------------------------------------
// 2) GLOBAL NO-CACHE – MÅSTE KOMMA EFTER STATIC
// ------------------------------------------------------------
app.use((req, res, next) => {
    res.set("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.set("Pragma", "no-cache");
    res.set("Expires", "0");
    res.set("Surrogate-Control", "no-store");
    next();
});

// ------------------------------------------------------------
// Middleware
// ------------------------------------------------------------
app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ extended: true }));

// ------------------------------------------------------------
// Ping – används av LAN-check.js
// ------------------------------------------------------------
app.get("/ping", (req, res) => {
    res.status(200).send("pong");
});

// ------------------------------------------------------------
// Version – används av UI för att visa v0003
// ------------------------------------------------------------
app.get("/api/status", (req, res) => {
    res.json({ version: "v0003" });
});

// ------------------------------------------------------------
// Service Worker – KILLER VERSION
// ------------------------------------------------------------
app.get("/service-worker.js", (req, res) => {
    res.set("Content-Type", "application/javascript");
    res.send(`
self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => self.clients.claim());
self.addEventListener('fetch', e => {});
`);
});

// ------------------------------------------------------------
// RÅFILER – EN-TENANT VERSION (KRITISK FIX)
// ------------------------------------------------------------
app.get("/files/raw/:filename", (req, res) => {
    const { filename } = req.params;

    const fullPath = path.join(
        __dirname,
        "data",
        "tenants",
        "default",
        "files",
        "raw",
        filename
    );

    const ext = path.extname(filename).toLowerCase();
    const mimeMap = {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".pdf": "application/pdf",
        ".txt": "text/plain",
        ".csv": "text/csv",
        ".log": "text/plain",
        ".md": "text/markdown",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".xls": "application/vnd.ms-excel"
    };

    if (mimeMap[ext]) {
        res.setHeader("Content-Type", mimeMap[ext]);
    }

    res.sendFile(fullPath, err => {
        if (err) res.status(404).send("Filen hittades inte");
    });
});

// ------------------------------------------------------------
// API – no-cache
// ------------------------------------------------------------
app.use("/api", (req, res, next) => {
    res.set("Cache-Control", "no-store");
    next();
}, require("./api"));

// ------------------------------------------------------------
// Root – startskärm (PROD VERSION)
// ------------------------------------------------------------
app.get("/", (req, res) => {
    res.send(`
        <html>
        <head>
            <title>SM Core v0003</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="icon" type="image/x-icon" href="/favicon.ico">
            <style>
                body {
                    margin: 0;
                    padding: 0;
                    background: #0d0d0d;
                    font-family: Arial, sans-serif;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    color: white;
                }
                .logo {
                    width: 200px;
                    height: 200px;
                    margin-bottom: 30px;
                }
                .button {
                    display: inline-block;
                    padding: 16px 28px;
                    background: #0078ff;
                    color: white;
                    text-decoration: none;
                    border-radius: 10px;
                    font-size: 22px;
                    font-weight: bold;
                    box-shadow: 0 0 15px rgba(0, 120, 255, 0.5);
                }
            </style>
        </head>
        <body>
            <img class="logo" src="/logo.png" alt="SM Core Logo">
            <a class="button" href="/index.html">Öppna SM‑CORE</a>
        </body>
        </html>
    `);
});

// ------------------------------------------------------------
// Starta server – ⭐ PROD PORT 3000
// ------------------------------------------------------------
const PORT = 3000;
app.listen(PORT, () => {
    console.log("SM Core v0003 server körs på port", PORT);
});
