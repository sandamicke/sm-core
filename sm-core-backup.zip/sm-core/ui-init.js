// ============================================================
// FILE: E:\sm-core\ui-init.js
// PURPOSE: Initiering av UI – ersätter inline-script i HTML
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

// ------------------------------------------------------------
// Service Worker – BORTTAGEN (orsakade cache + UI-fel)
// ------------------------------------------------------------
// Inget SW-block här längre. Ingen registrering. Ingen PWA.

// ------------------------------------------------------------
// UI-initiering
// ------------------------------------------------------------
document.addEventListener("DOMContentLoaded", () => {

    // ========================================================
    // INDEX.HTML
    // ========================================================
    const createBtn = document.getElementById("createJobBtn");
    if (createBtn) createBtn.onclick = createJob;

    const sortJobsSelect = document.getElementById("sortJobs");
    if (sortJobsSelect) sortJobsSelect.onchange = () => loadJobs();

    if (document.getElementById("jobList")) {
        loadJobs();
    }

    // ========================================================
    // JOB.HTML
    // ========================================================
    if (document.getElementById("jobTitle")) {
        loadJob();
        initCompleteButton();   // Kör direkt efter loadJob
    }

    const backBtn = document.getElementById("backBtn");
    if (backBtn) {
        backBtn.onclick = () => {
            window.location.href = "/";
        };
    }

    const beforeFile = document.getElementById("beforeFile");
    if (beforeFile) beforeFile.onchange = () => uploadFile("before");

    const afterFile = document.getElementById("afterFile");
    if (afterFile) afterFile.onchange = () => uploadFile("after");

    const docFile = document.getElementById("docFile");
    if (docFile) docFile.onchange = () => uploadFile("documents");

    const docSort = document.getElementById("docSort");
    if (docSort) docSort.onchange = () => changeSort("documents");
});

// ============================================================
// C2: Completed-knapp för jobbsidan
// ============================================================
function initCompleteButton() {
    const btn = document.getElementById("completeToggleBtn");
    if (!btn || !currentJob) return;

    btn.classList.remove("complete-btn-done", "complete-btn-undo");

    if (currentJob.completed) {
        btn.textContent = "↺ Ångra klart";
        btn.classList.add("complete-btn-undo");
        btn.onclick = async () => {
            await toggleComplete(currentJob.id, false);
            await loadJob();
            initCompleteButton();
        };
    } else {
        btn.textContent = "✔ Markera som klart";
        btn.classList.add("complete-btn-done");
        btn.onclick = async () => {
            await toggleComplete(currentJob.id, true);
            await loadJob();
            initCompleteButton();
        };
    }
}
