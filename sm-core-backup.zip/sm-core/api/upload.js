// ============================================================
// FILE: E:\sm-core\api\upload.js
// PURPOSE: API – Upload raw file → FileRef → pipeline.attachFile
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const express = require("express");
const router = express.Router();
const multer = require("multer");
const pipeline = require("../core/pipeline/pipeline");
const externalStorage = require("../core/storage/externalStorage");

// Multer – lagrar INTE filen på disk, vi tar buffern direkt
const upload = multer({ storage: multer.memoryStorage() });

// ------------------------------------------------------------
// Upload endpoint
// ------------------------------------------------------------
router.post("/:tenantId/:jobId/:slot", upload.single("file"), async (req, res) => {
    try {
        const { tenantId, jobId, slot } = req.params;

        if (!tenantId || !jobId || !slot) {
            return res.json({ error: "tenantId, jobId och slot krävs" });
        }

        // Endast tillåtna slots
        const validSlots = ["before", "after", "documents"];
        if (!validSlots.includes(slot)) {
            return res.json({ error: "Ogiltig slot" });
        }

        if (!req.file) {
            return res.json({ error: "Ingen fil mottagen" });
        }

        // 1. Spara råfil i extern lagring → få FileRef
        const fileRef = await externalStorage.saveRawFile({
            tenantId,
            buffer: req.file.buffer,
            originalName: req.file.originalname,
            mimeType: req.file.mimetype
        });

        if (!fileRef || !fileRef.id) {
            return res.json({ error: "Kunde inte spara råfil" });
        }

        // 2. Kör pipeline → attachFile
        const job = await pipeline.run("attachFile", {
            tenantId,
            jobId,
            fileRef,
            slot
        });

        res.json({
            success: true,
            job,
            fileRef
        });

    } catch (err) {
        console.error("Upload error:", err);
        res.json({ error: err.message });
    }
});

module.exports = router;
