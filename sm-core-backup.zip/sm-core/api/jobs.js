// ============================================================
// FILE: E:\sm-core\api\jobs.js
// PURPOSE: API – Job endpoints (stabil, intern datarot)
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const express = require("express");
const router = express.Router();
const pipeline = require("../core/pipeline/pipeline");
const storage = require("../core/storage/storage");

// ------------------------------------------------------------
// Skapa nytt jobb
// ------------------------------------------------------------
router.post("/create", async (req, res) => {
    try {
        const { tenantId, title } = req.body;

        if (!tenantId) {
            return res.json({ error: "tenantId krävs" });
        }

        const job = await pipeline.run("createJob", { tenantId, title });

        res.json({ success: true, job });
    } catch (err) {
        res.json({ error: err.message });
    }
});

// ------------------------------------------------------------
// Byt titel på jobb
// ------------------------------------------------------------
router.post("/rename", async (req, res) => {
    try {
        const { tenantId, jobId, newTitle } = req.body;

        if (!tenantId || !jobId) {
            return res.json({ error: "tenantId och jobId krävs" });
        }

        const job = await pipeline.run("renameJob", { tenantId, jobId, newTitle });

        res.json({ success: true, job });
    } catch (err) {
        res.json({ error: err.message });
    }
});

// ------------------------------------------------------------
// Ta bort jobb (POST istället för DELETE pga body-problem)
// ------------------------------------------------------------
router.post("/delete", async (req, res) => {
    try {
        const { tenantId, jobId } = req.body;

        if (!tenantId || !jobId) {
            return res.json({ error: "tenantId och jobId krävs" });
        }

        const result = await pipeline.run("deleteJob", { tenantId, jobId });

        res.json({ success: true, result });
    } catch (err) {
        res.json({ error: err.message });
    }
});

// ------------------------------------------------------------
// Lista alla jobb
// ------------------------------------------------------------
router.get("/list/:tenantId", async (req, res) => {
    try {
        const tenantId = req.params.tenantId;

        const project = await storage.loadProject(tenantId);

        const jobs = Array.isArray(project.jobs) ? project.jobs : [];

        res.json({
            success: true,
            jobs
        });

    } catch (err) {
        console.error("Job list error:", err);
        res.json({
            success: false,
            jobs: [],
            error: err.message
        });
    }
});

// ------------------------------------------------------------
// ⭐ C1: Markera jobb som avslutat
// ------------------------------------------------------------
router.post("/complete", async (req, res) => {
    try {
        const { tenantId, jobId, completed } = req.body;

        if (!tenantId || !jobId) {
            return res.json({ error: "tenantId och jobId krävs" });
        }

        const job = await pipeline.run("completeJob", {
            tenantId,
            jobId,
            completed: !!completed
        });

        res.json({ success: true, job });

    } catch (err) {
        res.json({ error: err.message });
    }
});

module.exports = router;
