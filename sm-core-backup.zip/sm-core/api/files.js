// ============================================================
// FILE: E:\sm-core\api\files.js
// PURPOSE: API – File attach/delete/rename + TXT create/update
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const express = require("express");
const router = express.Router();
const pipeline = require("../core/pipeline/pipeline");
const { tenantPaths } = require("../config/paths");
const fs = require("fs");
const path = require("path");

// ------------------------------------------------------------
// Lägg till fil
// ------------------------------------------------------------
router.post("/attach", async (req, res) => {
    try {
        const { tenantId, jobId, fileRef, slot } = req.body;

        if (!tenantId || !jobId || !fileRef || !slot) {
            return res.json({
                error: "tenantId, jobId, fileRef och slot krävs"
            });
        }

        const job = await pipeline.run("attachFile", {
            tenantId,
            jobId,
            fileRef,
            slot
        });

        res.json({ success: true, job });

    } catch (err) {
        res.json({ error: err.message });
    }
});

// ------------------------------------------------------------
// Ta bort fil
// ------------------------------------------------------------
router.post("/delete", async (req, res) => {
    try {
        const { tenantId, jobId, fileId } = req.body;

        if (!tenantId || !jobId || !fileId) {
            return res.json({
                error: "tenantId, jobId och fileId krävs"
            });
        }

        const job = await pipeline.run("deleteFile", {
            tenantId,
            jobId,
            fileId
        });

        res.json({ success: true, job });

    } catch (err) {
        res.json({ error: err.message });
    }
});

// ------------------------------------------------------------
// Byt namn på fil
// ------------------------------------------------------------
router.post("/rename", async (req, res) => {
    try {
        const { tenantId, jobId, fileId, newName } = req.body;

        if (!tenantId || !jobId || !fileId || !newName) {
            return res.json({
                error: "tenantId, jobId, fileId och newName krävs"
            });
        }

        const job = await pipeline.run("renameFile", {
            tenantId,
            jobId,
            fileId,
            newName
        });

        res.json({ success: true, job });

    } catch (err) {
        res.json({ error: err.message });
    }
});

// ------------------------------------------------------------
// Skapa ny TXT-fil (anteckningar)
// ------------------------------------------------------------
router.post("/createText", async (req, res) => {
    try {
        const { tenantId, jobId, content } = req.body;

        if (!tenantId || !jobId || typeof content !== "string") {
            return res.json({
                success: false,
                error: "tenantId, jobId och content krävs"
            });
        }

        const paths = tenantPaths(tenantId);
        const rawDir = path.join(paths.filesDir, "raw");

        const baseId = `note-${Date.now()}`;
        const fileName = `${baseId}.txt`;
        const filePath = path.join(rawDir, fileName);

        await fs.promises.writeFile(filePath, content, "utf8");

        const stats = await fs.promises.stat(filePath);

        // KORREKT fileRef för SM‑Core v0003
        const fileRef = {
            id: baseId,
            originalName: fileName,
            filename: fileName,
            type: "text/plain",
            size: stats.size,
            created: Date.now()
        };

        const job = await pipeline.run("attachFile", {
            tenantId,
            jobId,
            fileRef,
            slot: "documents"
        });

        res.json({ success: true, job });

    } catch (err) {
        console.error("createText error:", err);
        res.json({ success: false, error: err.message });
    }
});

// ------------------------------------------------------------
// Uppdatera befintlig TXT-fil
// ------------------------------------------------------------
router.post("/updateText", async (req, res) => {
    try {
        const { tenantId, fileName, content } = req.body;

        if (!tenantId || !fileName || typeof content !== "string") {
            return res.json({
                success: false,
                error: "tenantId, fileName och content krävs"
            });
        }

        const paths = tenantPaths(tenantId);
        const rawDir = path.join(paths.filesDir, "raw");
        const filePath = path.join(rawDir, fileName);

        await fs.promises.writeFile(filePath, content, "utf8");

        res.json({ success: true });

    } catch (err) {
        console.error("updateText error:", err);
        res.json({ success: false, error: err.message });
    }
});

module.exports = router;
