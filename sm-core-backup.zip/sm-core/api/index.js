// ============================================================
// FILE: E:\sm-core\api\index.js
// PURPOSE: API root router (stabil, intern datarot)
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const express = require("express");
const router = express.Router();

// Job endpoints (create, rename, list)
router.use("/jobs", require("./jobs"));

// File operations (attach/delete via pipeline)
router.use("/files", require("./files"));

// Raw file upload → externalStorage → FileRef → pipeline.attachFile
router.use("/upload", require("./upload"));

module.exports = router;
