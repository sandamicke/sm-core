// ============================================================
// FILE: E:\sm-core\ui-sort.js
// PURPOSE: Sorteringslogik (Modul 1)
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

// Håller sorteringsläge per slot (BEFORE/AFTER/DOCUMENTS)
const sortState = {
    before: "created_desc",
    after: "created_desc",
    documents: "created_desc"
};

// ------------------------------------------------------------
// Ändra sorteringsläge (BEFORE/AFTER/DOCUMENTS)
// ------------------------------------------------------------
function changeSort(slot) {
    const selectId = slot === "documents" ? "docSort" : `${slot}Sort`;
    const select = document.getElementById(selectId);
    if (!select) return;

    sortState[slot] = select.value;

    if (typeof renderSection === "function") {
        renderSection(slot);
    }
}

// ------------------------------------------------------------
// Sortera filer enligt valt läge (BEFORE/AFTER/DOCUMENTS)
// ------------------------------------------------------------
function sortFiles(files, mode) {
    if (!Array.isArray(files)) return [];

    const arr = files.slice();

    switch (mode) {
        case "created_asc":
            return arr.sort((a, b) =>
                new Date(a?.created || 0) - new Date(b?.created || 0)
            );

        case "created_desc":
            return arr.sort((a, b) =>
                new Date(b?.created || 0) - new Date(a?.created || 0)
            );

        case "name_asc":
            return arr.sort((a, b) =>
                (a?.originalName || "").localeCompare(b?.originalName || "")
            );

        case "name_desc":
            return arr.sort((a, b) =>
                (b?.originalName || "").localeCompare(a?.originalName || "")
            );

        case "type":
            return arr.sort((a, b) =>
                (a?.type || "").localeCompare(b?.type || "")
            );

        case "size":
            return arr.sort((a, b) =>
                (a?.size || 0) - (b?.size || 0)
            );

        default:
            return arr;
    }
}

// ============================================================
// JOBBLISTA – SEPARERAD SORTERING FÖR v0003
// ============================================================

function sortJobs(jobs) {
    if (!Array.isArray(jobs)) return [];

    const select = document.getElementById("sortJobs");
    if (!select) return jobs;

    const mode = select.value;

    switch (mode) {
        case "job_id_desc":   // Nr. nyast
            return jobs.slice().sort((a, b) =>
                Number(b?.id || 0) - Number(a?.id || 0)
            );

        case "job_id_asc":    // Nr. i ordning
            return jobs.slice().sort((a, b) =>
                Number(a?.id || 0) - Number(b?.id || 0)
            );

        case "job_title_asc": // A–Ö
            return jobs.slice().sort((a, b) =>
                (a?.title || "").localeCompare(b?.title || "")
            );

        case "job_title_desc": // Ö–A
            return jobs.slice().sort((a, b) =>
                (b?.title || "").localeCompare(a?.title || "")
            );

        default:
            return jobs;
    }
}
