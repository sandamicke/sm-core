// ============================================================
// FILE: E:\sm-core\lan-check.js
// PURPOSE: LAN-detektion – avgör om synk får köras
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

// ------------------------------------------------------------
// KONFIGURATION
// ------------------------------------------------------------
const HOME_GATEWAY_PREFIX = "192.168.";   // Hemnätets IP-range
const LOCAL_SERVER_URL = window.location.origin + "/ping";
const LAN_CHECK_TIMEOUT = 2000; // ms

// ------------------------------------------------------------
// WebRTC-baserad lokal IP-detektion (robust, feature-säkrad)
// ------------------------------------------------------------
async function detectLocalIP() {
    return new Promise(resolve => {
        let resolved = false;

        const safeResolve = value => {
            if (!resolved) {
                resolved = true;
                resolve(value);
            }
        };

        try {
            const RTCPeer =
                window.RTCPeerConnection ||
                window.webkitRTCPeerConnection ||
                window.mozRTCPeerConnection;

            if (!RTCPeer) {
                console.warn("LAN-check: RTCPeerConnection saknas – hoppar över IP-detektion.");
                safeResolve(null);
                return;
            }

            const rtc = new RTCPeer({ iceServers: [] });

            rtc.createDataChannel("x");
            rtc.createOffer()
                .then(offer => rtc.setLocalDescription(offer))
                .catch(err => {
                    console.warn("LAN-check: createOffer misslyckades:", err);
                    try { rtc.close(); } catch {}
                    safeResolve(null);
                });

            rtc.onicecandidate = event => {
                if (!event || !event.candidate || !event.candidate.candidate) return;

                const candidate = event.candidate.candidate;
                const ipMatch = candidate.match(/(\d+\.\d+\.\d+\.\d+)/);

                if (ipMatch) {
                    safeResolve(ipMatch[1]);
                    try { rtc.close(); } catch {}
                }
            };

            setTimeout(() => {
                try { rtc.close(); } catch {}
                safeResolve(null);
            }, 500);

        } catch (err) {
            console.warn("LAN-check: WebRTC IP-detektion misslyckades:", err);
            safeResolve(null);
        }
    });
}

// ------------------------------------------------------------
// Testa om lokal server svarar
// ------------------------------------------------------------
async function testLocalServer() {
    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), LAN_CHECK_TIMEOUT);

        const response = await fetch(LOCAL_SERVER_URL, {
            method: "GET",
            signal: controller.signal
        });

        clearTimeout(timeout);

        return response.ok;
    } catch (err) {
        console.warn("LAN-check: testLocalServer misslyckades:", err);
        return false;
    }
}

// ------------------------------------------------------------
// Huvudfunktion: Är vi hemma?
// ------------------------------------------------------------
async function isHomeLAN() {
    try {
        const ip = await detectLocalIP();

        if (!ip) {
            console.warn("LAN-check: Kunde inte läsa lokal IP.");
            return false;
        }

        if (!ip.startsWith(HOME_GATEWAY_PREFIX)) {
            console.log("LAN-check: IP matchar inte hemnät.");
            return false;
        }

        const serverOK = await testLocalServer();
        if (!serverOK) {
            console.log("LAN-check: Lokal server svarar inte.");
            return false;
        }

        console.log("LAN-check: Hemnät bekräftat.");
        return true;

    } catch (err) {
        console.error("LAN-check: Fel vid kontroll:", err);
        return false;
    }
}

// ------------------------------------------------------------
// Exponera globalt
// ------------------------------------------------------------
window.isHomeLAN = isHomeLAN;
