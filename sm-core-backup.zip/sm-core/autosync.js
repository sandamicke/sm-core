// ============================================================
// FILE: E:\sm-core\autosync.js
// PURPOSE: Autosync – inaktiv i v0003 (säker, komplett stub)
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

// ------------------------------------------------------------
// Inaktiva inställningar (behålls för kompatibilitet)
// ------------------------------------------------------------
const AUTOSYNC_INTERVAL = 60 * 1000;
let autosyncRunning = false;

// ------------------------------------------------------------
// Inaktiv autosync – gör ingenting men kastar aldrig fel
// ------------------------------------------------------------
async function autosyncCheck() {
    return false;
}

// ------------------------------------------------------------
// Inaktiverad timer – körs men gör ingenting
// ------------------------------------------------------------
window.addEventListener("load", () => {
    setInterval(() => {
        autosyncCheck();
    }, AUTOSYNC_INTERVAL);
});

// ------------------------------------------------------------
// Exponera globalt (krävs av UI)
// ------------------------------------------------------------
window.autosyncCheck = autosyncCheck;
