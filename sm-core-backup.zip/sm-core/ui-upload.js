// ============================================================
// FILE: E:\sm-core\ui-upload.js
// PURPOSE: Upload + Drag-and-drop (Modul 4)
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

// ------------------------------------------------------------
// Hjälp: hämta jobId från URL
// ------------------------------------------------------------
function getJobIdFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get("id");
}

// ------------------------------------------------------------
// Ladda upp fil (input + drag-and-drop)
// ------------------------------------------------------------
async function uploadFile(slot, fileOverride) {
    try {
        const jobId = getJobIdFromUrl();
        if (!jobId) return;

        const inputMap = {
            before: document.getElementById("beforeFile"),
            after: document.getElementById("afterFile"),
            documents: document.getElementById("docFile")
        };

        const input = inputMap[slot];
        const file = fileOverride || (input && input.files && input.files[0]);
        if (!file) return;

        // Förhindra dubbeltrigger
        if (uploadFile._lock) return;
        uploadFile._lock = true;

        const form = new FormData();
        form.append("file", file);

        const res = await fetch(`/api/upload/${TENANT}/${jobId}/${slot}`, {
            method: "POST",
            body: form
        });

        const data = await res.json();

        if (data.success && data.job) {
            currentJob = data.job;

            if (typeof renderSection === "function") {
                renderSection(slot);
            }
        } else {
            console.error("Fel vid uploadFile:", data.error);
        }

        if (input) input.value = "";

    } catch (err) {
        console.error("Fel vid uploadFile:", err);
    } finally {
        uploadFile._lock = false;
    }
}

// ------------------------------------------------------------
// Drag-and-drop-zoner
// ------------------------------------------------------------
function setupDropZone(elementId, slot) {
    const dz = document.getElementById(elementId);
    if (!dz) return;

    dz.addEventListener("dragover", e => {
        e.preventDefault();
        dz.classList.add("dragover");
    });

    dz.addEventListener("dragleave", e => {
        e.preventDefault();
        dz.classList.remove("dragover");
    });

    dz.addEventListener("drop", e => {
        e.preventDefault();
        dz.classList.remove("dragover");

        const files = e.dataTransfer?.files;
        if (!files || files.length === 0) return;

        uploadFile(slot, files[0]);
    });
}
