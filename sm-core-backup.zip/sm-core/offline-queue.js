// ============================================================
// FILE: E:\sm-core\offline-queue.js
// PURPOSE: Offline-lagring av jobb, filer och anteckningar
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

// ------------------------------------------------------------
// IndexedDB – smcore-offline
// ------------------------------------------------------------
const DB_NAME = "smcore-offline";
const DB_VERSION = 1;
const STORE_NAME = "queue";

// ------------------------------------------------------------
// Öppna eller skapa databasen
// ------------------------------------------------------------
function openDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = event => {
            const db = event.target.result;

            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME, { keyPath: "id", autoIncrement: true });
            }
        };

        request.onsuccess = event => resolve(event.target.result);
        request.onerror = event => reject(event.target.error);
    });
}

// ------------------------------------------------------------
// Lägg till post i kön
// ------------------------------------------------------------
async function queueAdd(type, payload) {
    try {
        const db = await openDB();

        return await new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, "readwrite");
            const store = tx.objectStore(STORE_NAME);

            const entry = {
                type,
                payload,
                timestamp: Date.now()
            };

            const request = store.add(entry);

            request.onsuccess = event => resolve(event.target.result);
            request.onerror = event => reject(event.target.error);

            tx.onerror = err => reject(err);
        });
    } catch (err) {
        console.error("queueAdd fel:", err);
        return null;
    }
}

// ------------------------------------------------------------
// Hämta hela kön
// ------------------------------------------------------------
async function queueGetAll() {
    try {
        const db = await openDB();

        return await new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, "readonly");
            const store = tx.objectStore(STORE_NAME);

            const request = store.getAll();

            request.onsuccess = event => resolve(event.target.result || []);
            request.onerror = event => reject(event.target.error);

            tx.onerror = err => reject(err);
        });
    } catch (err) {
        console.error("queueGetAll fel:", err);
        return [];
    }
}

// ------------------------------------------------------------
// Ta bort post från kön
// ------------------------------------------------------------
async function queueRemove(id) {
    try {
        const db = await openDB();

        return await new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, "readwrite");
            const store = tx.objectStore(STORE_NAME);

            const request = store.delete(id);

            request.onsuccess = () => resolve(true);
            request.onerror = event => reject(event.target.error);

            tx.onerror = err => reject(err);
        });
    } catch (err) {
        console.error("queueRemove fel:", err);
        return false;
    }
}

// ------------------------------------------------------------
// Töm hela kön (används efter lyckad synk)
// ------------------------------------------------------------
async function queueClear() {
    try {
        const db = await openDB();

        return await new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, "readwrite");
            const store = tx.objectStore(STORE_NAME);

            const request = store.clear();

            request.onsuccess = () => resolve(true);
            request.onerror = event => reject(event.target.error);

            tx.onerror = err => reject(err);
        });
    } catch (err) {
        console.error("queueClear fel:", err);
        return false;
    }
}
