// ============================================================
// FILE: E:\sm-core\ui.js
// PURPOSE: Huvud-UI (Bootstrap) – stabil version utan tysta fel
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const TENANT = "default";
let currentJob = null;
let editingFileName = null;
let aiFiles = [];

// ------------------------------------------------------------
// Robust fetch-wrapper (bypassar cache och SW)
// ------------------------------------------------------------
async function api(url, options = {}) {
    const fullUrl = window.location.origin + url;

    const noCacheOptions = {
        ...options,
        headers: {
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0",
            ...(options.headers || {})
        }
    };

    const res = await fetch(fullUrl, noCacheOptions);
    return res.json();
}

// ------------------------------------------------------------
// Ladda alla jobb (index.html) – C1 + C2 IMPLEMENTERAD
// ------------------------------------------------------------
async function loadJobs() {
    try {
        const data = await api(`/api/jobs/list/${TENANT}`);

        const activeList = document.getElementById("jobList");
        const completedList = document.getElementById("completedJobList");

        if (!activeList || !completedList) return;

        activeList.innerHTML = "";
        completedList.innerHTML = "";

        if (!data.success || !Array.isArray(data.jobs)) {
            activeList.innerHTML = "<li>Inga jobb hittades</li>";
            return;
        }

        let jobs = data.jobs;

        // Fallback-sortering
        try {
            if (typeof sortJobs === "function") {
                jobs = sortJobs(jobs);
            }
        } catch (e) {
            console.warn("sortJobs saknas – använder osorterad lista");
        }

        // *** KRITISK FIX: GLOBAL REFERENS ***
        window.jobs = jobs;

        // --------------------------------------------------------
        // C1: Dela upp jobb i aktiva och avslutade
        // --------------------------------------------------------
        const activeJobs = jobs.filter(j => !j.completed);
        const completedJobs = jobs.filter(j => j.completed);

        // --------------------------------------------------------
        // Rendera aktiva jobb
        // --------------------------------------------------------
        activeJobs.forEach(job => {
            const li = document.createElement("li");
            li.className = "job-row";

            const titleSpan = document.createElement("span");
            titleSpan.className = "job-title";
            titleSpan.textContent = `${job.id} – ${job.title}`;
            titleSpan.onclick = () => {
                window.location.href = `/job.html?id=${job.id}`;
            };

            const spacer = document.createElement("div");
            spacer.className = "job-spacer";

            // ⭐ C2: Markera som klart
            const completeBtn = document.createElement("button");
            completeBtn.className = "file-btn complete-btn-done";
            completeBtn.textContent = "✔ Klart";
            completeBtn.onclick = async () => {
                await toggleComplete(job.id, true);
                await loadJobs();
            };

            // ⭐ A: Ikon + text
            const renameBtn = document.createElement("button");
            renameBtn.className = "file-btn";
            renameBtn.textContent = "✏️ Byt namn";
            renameBtn.onclick = () => renameJobUI(job.id);

            const deleteBtn = document.createElement("button");
            deleteBtn.className = "file-btn file-btn-danger";
            deleteBtn.textContent = "🗑 Ta bort";
            deleteBtn.onclick = () => deleteJob(job.id);

            li.appendChild(titleSpan);
            li.appendChild(spacer);
            li.appendChild(completeBtn);
            li.appendChild(renameBtn);
            li.appendChild(deleteBtn);

            activeList.appendChild(li);
        });

        // --------------------------------------------------------
        // Rendera avslutade jobb (C1 + C2)
        // --------------------------------------------------------
        completedJobs.forEach(job => {
            const li = document.createElement("li");
            li.className = "job-row completed-job";

            const titleSpan = document.createElement("span");
            titleSpan.className = "job-title";
            titleSpan.textContent = `${job.id} – ${job.title}`;
            titleSpan.onclick = () => {
                window.location.href = `/job.html?id=${job.id}`;
            };

            const spacer = document.createElement("div");
            spacer.className = "job-spacer";

            // ⭐ C2: Ångra klart
            const undoBtn = document.createElement("button");
            undoBtn.className = "file-btn complete-btn-undo";
            undoBtn.textContent = "↺ Ångra";
            undoBtn.onclick = async () => {
                await toggleComplete(job.id, false);
                await loadJobs();
            };

            // ⭐ A: Ikon + text
            const renameBtn = document.createElement("button");
            renameBtn.className = "file-btn";
            renameBtn.textContent = "✏️ Byt namn";
            renameBtn.onclick = () => renameJobUI(job.id);

            const deleteBtn = document.createElement("button");
            deleteBtn.className = "file-btn file-btn-danger";
            deleteBtn.textContent = "🗑 Ta bort";
            deleteBtn.onclick = () => deleteJob(job.id);

            li.appendChild(titleSpan);
            li.appendChild(spacer);
            li.appendChild(undoBtn);
            li.appendChild(renameBtn);
            li.appendChild(deleteBtn);

            completedList.appendChild(li);
        });

    } catch (err) {
        console.error("Fel vid loadJobs:", err);
    }
}

// ------------------------------------------------------------
// Skapa nytt jobb
// ------------------------------------------------------------
async function createJob() {
    try {
        const titleInput = document.getElementById("newTitle");
        if (!titleInput) return;

        const title = titleInput.value.trim();
        if (!title) return;

        const data = await api("/api/jobs/create", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ tenantId: TENANT, title })
        });

        if (data.success) {
            titleInput.value = "";
            loadJobs();
        } else {
            console.error("Fel vid createJob:", data.error);
        }
    } catch (err) {
        console.error("Fel vid createJob:", err);
    }
}

// ------------------------------------------------------------
// Ladda ett specifikt jobb (job.html)
// ------------------------------------------------------------
async function loadJob() {
    try {
        const params = new URLSearchParams(window.location.search);
        const jobId = params.get("id");
        if (!jobId) return;

        const data = await api(`/api/jobs/list/${TENANT}`);
        if (!data.success || !Array.isArray(data.jobs)) return;

        const job = data.jobs.find(j => String(j.id) === String(jobId));
        if (!job) return;

        currentJob = job;

        const titleEl = document.getElementById("jobTitle");
        if (titleEl) {
            titleEl.innerText = `${job.id} – ${job.title}`;
        }

        renderSection("before");
        renderSection("after");
        renderSection("documents");

        setupDropZone("beforeDrop", "before");
        setupDropZone("afterDrop", "after");
        setupDropZone("docDrop", "documents");

    } catch (err) {
        console.error("Fel vid loadJob:", err);
    }
}

// ------------------------------------------------------------
// Initiera UI vid sidladdning
// ------------------------------------------------------------
document.addEventListener("DOMContentLoaded", () => {
    if (document.getElementById("jobList")) {
        loadJobs();

        // --------------------------------------------------------
        // C1: Toggle-knapp för avslutade jobb
        // --------------------------------------------------------
        const btn = document.getElementById("toggleCompletedBtn");
        const completedList = document.getElementById("completedJobList");

        if (btn && completedList) {
            btn.onclick = () => {
                const visible = completedList.style.display === "block";
                completedList.style.display = visible ? "none" : "block";
                btn.textContent = visible ? "Visa avslutade jobb" : "Dölj avslutade jobb";
            };
        }
    }

    if (document.getElementById("jobTitle")) {
        loadJob();
    }
});

// ------------------------------------------------------------
// EXPORTERA FUNKTIONER GLOBALT (KRITISK FIX)
// ------------------------------------------------------------
window.loadJobs = loadJobs;
window.createJob = createJob;
window.loadJob = loadJob;
