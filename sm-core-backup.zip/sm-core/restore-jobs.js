const fs = require("fs");
const path = require("path");

const jobsFile = path.join(__dirname, "data", "tenants", "default", "jobs.json");

// Läs JSON-filen du skickade
const raw = fs.readFileSync(jobsFile, "utf8");
const parsed = JSON.parse(raw);

// Skapa en ren lista för localStorage-formatet
const jobList = parsed.jobs.map(j => ({
    id: j.id,
    title: j.title,
    status: j.status,
    created: j.created
}));

// Skriv ut filen som UI använder
const output = path.join(__dirname, "data", "tenants", "default", "jobs-ui.json");
fs.writeFileSync(output, JSON.stringify(jobList, null, 2));

console.log("Jobblistan är återställd:");
console.log(jobList);
