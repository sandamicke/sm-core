// ============================================================
// FILE: E:\sm-core\ui-render.js
// PURPOSE: Rendering + Ikoner (Modul 3) + Jobblista med färgkodning
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

function getFileIcon(file) {
    if (!file) return "📁";

    const type = file.type || "";
    const name = (file.originalName || "").toLowerCase();

    if (type.startsWith("image/")) return "🖼";
    if (type === "application/pdf" || name.endsWith(".pdf")) return "📕";
    if (name.endsWith(".xlsx") || name.endsWith(".xls")) return "📊";
    if (name.endsWith(".doc") || name.endsWith(".docx")) return "📄";
    if (name.endsWith(".txt")) return "📝";
    return "📁";
}

function renderSection(slot) {
    if (!currentJob) return;

    const files = Array.isArray(currentJob[slot]) ? currentJob[slot] : [];

    const containerId =
        slot === "before" ? "beforeList" :
        slot === "after" ? "afterList" :
        "docList";

    const div = document.getElementById(containerId);
    if (!div) return;

    let sorted = files;

    if (slot === "documents") {
        try {
            sorted = sortFiles(files, sortState[slot] || "created_desc");
        } catch (e) {
            console.warn("sortFiles fel – använder osorterad lista");
        }
    }

    div.innerHTML = "";

    const jobId = currentJob.id;

    sorted.forEach(f => {
        if (!f) return;

        const safeName = f.originalName || "";
        const lower = safeName.toLowerCase();

        const row = document.createElement("div");
        row.className = "file-row-modern";

        const icon = document.createElement("span");
        icon.className = "file-icon-modern";
        icon.innerText = getFileIcon(f);

        const link = document.createElement("span");
        link.className = "file-name-modern";
        link.innerText = safeName;
        link.onclick = () => {
            if (f.filename && !f.url) {
                f.url = `/files/raw/${f.filename}`;
            }
            lastPreviewedFile = f;
            window.previewFile && window.previewFile(f);
        };

        const actions = document.createElement("div");
        actions.className = "file-actions-modern";

        const previewBtn = document.createElement("button");
        previewBtn.className = "file-btn";
        previewBtn.innerText = "👁 Visa";
        previewBtn.onclick = () => {
            if (f.filename && !f.url) {
                f.url = `/files/raw/${f.filename}`;
            }
            lastPreviewedFile = f;
            window.previewFile && window.previewFile(f);
        };
        actions.appendChild(previewBtn);

        if (lower.endsWith(".txt")) {
            const editBtn = document.createElement("button");
            editBtn.className = "file-btn";
            editBtn.innerText = "✍️ Redigera";
            editBtn.onclick = () =>
                editTextFile(`/files/raw/${f.filename}`, f.filename);
            actions.appendChild(editBtn);

            const openBtn = document.createElement("button");
            openBtn.className = "file-btn";
            openBtn.innerText = "📂 Öppna";
            openBtn.onclick = () => downloadAndOpen(f);
            actions.appendChild(openBtn);
        }

        const renameBtn = document.createElement("button");
        renameBtn.className = "file-btn";
        renameBtn.innerText = "✏️ Byt namn";
        renameBtn.onclick = () => renameFile(jobId, f.id, safeName);
        actions.appendChild(renameBtn);

        const deleteBtn = document.createElement("button");
        deleteBtn.className = "file-btn file-btn-danger";
        deleteBtn.innerText = "🗑 Ta bort";
        deleteBtn.onclick = () => deleteFile(jobId, f.id, safeName);
        actions.appendChild(deleteBtn);

        row.appendChild(icon);
        row.appendChild(link);
        row.appendChild(actions);

        div.appendChild(row);
    });
}

// ============================================================
// Jobblista – aktiv + completed med färgkodad knapp
// ============================================================

function renderJobLists(jobs) {

    const activeList = document.getElementById("jobList");
    const completedList = document.getElementById("completedJobList");

    if (!activeList || !completedList) return;

    activeList.innerHTML = "";
    completedList.innerHTML = "";

    for (const job of jobs) {

        job.completed = job.completed === true;

        const li = document.createElement("li");
        li.className = job.completed ? "completed-job" : "";
        li.dataset.id = job.id;

        const titleSpan = document.createElement("span");
        titleSpan.textContent = `${job.id} – ${job.title}`;
        titleSpan.className = "job-title";
        titleSpan.onclick = () => openJob(job.id);

        // ⭐ WRAPPER FÖR KNAPPAR (ENDA ÄNDRINGEN)
        const btnRow = document.createElement("div");
        btnRow.className = "job-buttons";

        const completeBtn = document.createElement("button");
        completeBtn.className = "file-btn";
        completeBtn.style.marginRight = "6px";

        completeBtn.classList.remove("complete-btn-done", "complete-btn-undo");

        if (job.completed) {
            completeBtn.textContent = "↺ Ångra";
            completeBtn.classList.add("complete-btn-undo");
            completeBtn.onclick = () => toggleComplete(job.id, false);
        } else {
            completeBtn.textContent = "✔ Klart";
            completeBtn.classList.add("complete-btn-done");
            completeBtn.onclick = () => toggleComplete(job.id, true);
        }

        const editBtn = document.createElement("button");
        editBtn.className = "file-btn";
        editBtn.textContent = "✎";
        editBtn.onclick = () => renameJobUI(job.id);

        const delBtn = document.createElement("button");
        delBtn.className = "file-btn-danger";
        delBtn.textContent = "🗑";
        delBtn.onclick = () => deleteJob(job.id);

        // ⭐ Lägg knapparna i wrappern
        btnRow.appendChild(completeBtn);
        btnRow.appendChild(editBtn);
        btnRow.appendChild(delBtn);

        li.appendChild(titleSpan);
        li.appendChild(btnRow);

        if (job.completed) {
            completedList.appendChild(li);
        } else {
            activeList.appendChild(li);
        }
    }
}
