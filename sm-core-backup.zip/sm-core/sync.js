// ============================================================
// FILE: E:\sm-core\sync.js
// PURPOSE: Synk-motor – skickar offline-data till servern
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

// ------------------------------------------------------------
// API-endpoint för synk
// ------------------------------------------------------------
const SYNC_ENDPOINT = window.location.origin + "/api/sync-upload";

// ------------------------------------------------------------
// Kör synk manuellt (UI-knapp eller fallback)
// ------------------------------------------------------------
async function runSync() {
    try {
        const queue = await queueGetAll().catch(() => []);

        if (!queue || queue.length === 0) {
            console.log("SM Core Sync: Ingen data att synka.");
            return true;
        }

        console.log(`SM Core Sync: Startar synk av ${queue.length} poster.`);

        for (const entry of queue) {
            const success = await sendEntry(entry);

            if (!success) {
                console.warn("SM Core Sync: Synk avbruten pga fel.");
                return false;
            }

            // Ta bort posten först EFTER lyckad synk
            await queueRemove(entry.id).catch(err => {
                console.error("SM Core Sync: Kunde inte ta bort köpost:", err);
            });
        }

        console.log("SM Core Sync: Synk slutförd.");
        return true;

    } catch (err) {
        console.error("SM Core Sync: Fel vid synk:", err);
        return false;
    }
}

// ------------------------------------------------------------
// Skicka en enskild post till servern
// ------------------------------------------------------------
async function sendEntry(entry) {
    try {
        const response = await fetch(SYNC_ENDPOINT, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(entry)
        });

        if (!response.ok) {
            console.error("SM Core Sync: Servern returnerade fel:", response.status);
            return false;
        }

        return true;

    } catch (err) {
        console.error("SM Core Sync: Nätverksfel:", err);
        return false;
    }
}

// ------------------------------------------------------------
// Service Worker Background Sync – anropas från SW
// ------------------------------------------------------------
async function backgroundSyncHandler() {
    console.log("SM Core Sync: Background Sync triggat.");
    return await runSync();
}

// ------------------------------------------------------------
// Exponera funktioner globalt
// ------------------------------------------------------------
window.runSync = runSync;
window.backgroundSyncHandler = backgroundSyncHandler;
