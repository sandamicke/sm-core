// ============================================================
// FILE: E:\sm-core\core\domain\fileRef.js
// PURPOSE: Domänmodell – FileRef
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: This header is grep-friendly och måste förbli intakt.
// ============================================================

class FileRef {
    constructor({
        id,
        tenantId,
        url,
        type,
        size,
        checksum,
        originalName,
        created = null
    }) {
        if (!id) throw new Error("FileRef: id saknas");
        if (!tenantId) throw new Error("FileRef: tenantId saknas");
        if (!url) throw new Error("FileRef: url saknas");
        if (!originalName) throw new Error("FileRef: originalName saknas");

        this.id = String(id);              // unikt fil-ID
        this.tenantId = tenantId;          // vilket konto filen tillhör
        this.url = url;                    // extern lagring (OneDrive/S3/NAS)
        this.type = type || "application/octet-stream";
        this.size = size || 0;
        this.checksum = checksum || null;  // sha256
        this.originalName = originalName;  // filnamn som användaren laddade upp
        this.created = created || new Date().toISOString();
    }
}

module.exports = FileRef;
