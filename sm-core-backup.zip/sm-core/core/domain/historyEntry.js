// ============================================================
// FILE: E:\sm-core\core\domain\historyEntry.js
// PURPOSE: Domänmodell – HistoryEntry
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: This header is grep-friendly and must remain intact.
// ============================================================

class HistoryEntry {
    constructor({
        id,
        tenantId,
        jobId,
        action,
        payload = {},
        created = null
    }) {
        if (!id) throw new Error("HistoryEntry: id saknas");
        if (!tenantId) throw new Error("HistoryEntry: tenantId saknas");
        if (!jobId) throw new Error("HistoryEntry: jobId saknas");
        if (!action) throw new Error("HistoryEntry: action saknas");

        this.id = String(id);          // unikt historik-ID
        this.tenantId = tenantId;      // vilket konto
        this.jobId = jobId;            // vilket jobb ändrades
        this.action = action;          // t.ex. "job.created", "file.attached", "job.renamed"
        this.payload = payload || {};  // detaljer om ändringen
        this.created = created || new Date().toISOString();
    }
}

module.exports = HistoryEntry;
