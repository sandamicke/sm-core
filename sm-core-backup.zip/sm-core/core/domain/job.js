// ============================================================
// FILE: E:\sm-core\core\domain\job.js
// PURPOSE: Domänmodell – Job
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: This header is grep-friendly and must remain intact.
// ============================================================

class Job {
    constructor({
        id,
        tenantId,
        title = "",
        status = "new",
        created = null,
        before = [],
        after = [],
        documents = []
    }) {
        if (!id) throw new Error("Job: id saknas");
        if (!tenantId) throw new Error("Job: tenantId saknas");

        this.id = String(id);          // t.ex. "10001" eller "10001-1"
        this.tenantId = tenantId;      // obligatoriskt
        this.title = title;
        this.status = status;          // "new", "active", "done", etc.
        this.created = created || new Date().toISOString();

        // FileRefs (inte råfiler)
        this.before = Array.isArray(before) ? before : [];
        this.after = Array.isArray(after) ? after : [];
        this.documents = Array.isArray(documents) ? documents : [];
    }
}

module.exports = Job;
