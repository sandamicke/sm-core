// ============================================================
// FILE: E:\sm-core\core\pipeline\pipeline.js
// PURPOSE: Pipeline dispatcher (stabil, intern datarot)
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const fs = require("fs");
const path = require("path");

class Pipeline {
    constructor() {
        this.commands = {};
    }

    // Registrera ett kommando
    register(name, handler) {
        if (typeof handler !== "function") {
            throw new Error(`Pipeline-kommando '${name}' måste vara en funktion`);
        }
        this.commands[name] = handler;
    }

    // Kör ett kommando
    async run(name, payload) {
        const cmd = this.commands[name];
        if (!cmd) {
            throw new Error(`Pipeline-kommando saknas: ${name}`);
        }

        return await cmd(payload);
    }
}

const pipeline = new Pipeline();

// ------------------------------------------------------------
// Ladda alla kommandon automatiskt
// ------------------------------------------------------------
const commandsDir = path.join(__dirname, "commands");

fs.readdirSync(commandsDir)
    .filter(file => file.endsWith(".js"))
    .forEach(file => {
        const commandName = file.replace(".js", "");
        const handler = require(path.join(commandsDir, file));

        pipeline.register(commandName, handler);
    });

module.exports = pipeline;
