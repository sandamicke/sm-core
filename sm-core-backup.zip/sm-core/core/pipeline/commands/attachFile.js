// ============================================================
// FILE: E:\sm-core\core\pipeline\commands\attachFile.js
// PURPOSE: Pipeline command – attachFile
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const HistoryEntry = require("../../domain/historyEntry");
const storage = require("../../storage/storage");
const path = require("path");

module.exports = async function attachFile({ tenantId, jobId, fileRef, slot }) {

    if (!tenantId) throw new Error("attachFile: tenantId saknas");
    if (!jobId) throw new Error("attachFile: jobId saknas");
    if (!fileRef) throw new Error("attachFile: fileRef saknas");

    const project = await storage.loadProject(tenantId);
    if (!Array.isArray(project.jobs)) project.jobs = [];

    const job = project.jobs.find(j => j.id === jobId);
    if (!job) throw new Error("Jobb hittades inte");

    job.before = job.before || [];
    job.after = job.after || [];
    job.documents = job.documents || [];

    // ------------------------------------------------------------
    // EXTRAHERA FILÄNDELSE
    // ------------------------------------------------------------
    const ext = path.extname(fileRef.originalName || "").toLowerCase() || ".bin";

    // ------------------------------------------------------------
    // KORREKT NORMALISERING FÖR SM‑CORE v0003
    // ------------------------------------------------------------
    const normalized = {
        id: fileRef.id,                                 // unikt ID
        originalName: fileRef.originalName || "okänd-fil",
        filename: `${fileRef.id}${ext}`,                // filnamn i raw/
        type: fileRef.type || "application/octet-stream",
        size: fileRef.size || 0,
        created: fileRef.created || Date.now()
    };

    // ------------------------------------------------------------
    // Placera filen i rätt slot
    // ------------------------------------------------------------
    switch (slot) {
        case "before":
            job.before = [normalized];
            break;

        case "after":
            job.after = [normalized];
            break;

        case "documents":
            job.documents.unshift(normalized); // senaste först
            break;

        default:
            throw new Error("Ogiltigt slot");
    }

    // ------------------------------------------------------------
    // Historik
    // ------------------------------------------------------------
    const history = new HistoryEntry({
        id: `hist-${Date.now()}`,
        tenantId,
        jobId,
        action: "file.attached",
        payload: {
            slot,
            fileId: normalized.id,
            originalName: normalized.originalName
        }
    });

    await storage.appendHistory(tenantId, history);
    await storage.saveProject(tenantId, project);

    return job;
};
