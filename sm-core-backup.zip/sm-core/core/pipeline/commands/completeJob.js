// ============================================================
// FILE: E:\sm-core\core\pipeline\commands\completeJob.js
// PURPOSE: Pipeline command – completeJob (markera jobb som klart/ej klart)
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const HistoryEntry = require("../../domain/historyEntry");
const storage = require("../../storage/storage");

module.exports = async function completeJob({ tenantId, jobId, completed }) {

    if (!tenantId) {
        throw new Error("completeJob: tenantId saknas");
    }

    if (!jobId) {
        throw new Error("completeJob: jobId saknas");
    }

    // 1. Ladda projekt
    const project = await storage.loadProject(tenantId);

    if (!Array.isArray(project.jobs)) {
        project.jobs = [];
    }

    // 2. Hitta jobb
    const job = project.jobs.find(j => String(j.id) === String(jobId));
    if (!job) {
        throw new Error(`completeJob: jobb ${jobId} hittades inte`);
    }

    // 3. Sätt completed-flagga (C1)
    job.completed = !!completed;

    // 4. Logga historik
    const history = new HistoryEntry({
        id: `hist-${Date.now()}`,
        tenantId,
        jobId: job.id,
        action: "job.completed",
        payload: { completed: job.completed }
    });

    await storage.appendHistory(tenantId, history);

    // 5. Spara projekt
    await storage.saveProject(tenantId, project);

    return job;
};
