// ============================================================
// FILE: E:\sm-core\core\pipeline\commands\deleteJob.js
// PURPOSE: Pipeline command – deleteJob
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const fs = require("fs");
const path = require("path");
const HistoryEntry = require("../../domain/historyEntry");
const storage = require("../../storage/storage");
const { tenantPaths } = require("../../../config/paths");

module.exports = async function deleteJob({ tenantId, jobId }) {

    if (!tenantId) throw new Error("deleteJob: tenantId saknas");
    if (!jobId) throw new Error("deleteJob: jobId saknas");

    const paths = tenantPaths(tenantId);

    // 1. Ladda projekt
    const project = await storage.loadProject(tenantId);
    if (!Array.isArray(project.jobs)) project.jobs = [];

    // 2. Hitta jobbet
    const job = project.jobs.find(j => j.id === jobId);
    if (!job) throw new Error("Jobb hittades inte");

    // 3. Ta bort alla filer som tillhör jobbet
    const allFiles = [
        ...(job.before || []),
        ...(job.after || []),
        ...(job.documents || [])
    ];

    for (const f of allFiles) {
        if (!f || !f.filename) continue;   // <-- KRITISK FIX

        const fullPath = path.join(paths.filesRaw, f.filename);

        if (fs.existsSync(fullPath)) {
            try {
                fs.rmSync(fullPath, { force: true });
            } catch (err) {
                console.error("Kunde inte ta bort fil:", fullPath, err);
            }
        }
    }

    // 4. Ta bort historikposter för jobbet
    if (fs.existsSync(paths.historyDir)) {
        const entries = fs.readdirSync(paths.historyDir);

        for (const file of entries) {
            const full = path.join(paths.historyDir, file);

            try {
                const raw = fs.readFileSync(full, "utf8");
                const parsed = JSON.parse(raw);

                if (parsed.jobId === jobId) {
                    fs.rmSync(full, { force: true });
                }
            } catch {
                // hoppa över korrupt historik
            }
        }
    }

    // 5. Ta bort jobbet från projektet
    project.jobs = project.jobs.filter(j => j.id !== jobId);

    // 6. Logga historik
    const history = new HistoryEntry({
        id: `hist-${Date.now()}`,
        tenantId,
        jobId,
        action: "job.deleted",
        payload: { deleted: true }
    });

    await storage.appendHistory(tenantId, history);

    // 7. Spara projekt
    await storage.saveProject(tenantId, project);

    // 8. Returnera uppdaterad jobblista
    return project.jobs;
};
