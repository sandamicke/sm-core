// ============================================================
// FILE: E:\sm-core\core\pipeline\commands\renameJob.js
// PURPOSE: Pipeline command – renameJob
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const HistoryEntry = require("../../domain/historyEntry");
const storage = require("../../storage/storage");

module.exports = async function renameJob({ tenantId, jobId, newTitle }) {

    if (!tenantId) {
        throw new Error("renameJob: tenantId saknas");
    }
    if (!jobId) {
        throw new Error("renameJob: jobId saknas");
    }

    // 1. Ladda projekt
    const project = await storage.loadProject(tenantId);

    if (!Array.isArray(project.jobs)) {
        project.jobs = [];
    }

    // 2. Hitta jobb
    const job = project.jobs.find(j => j.id === jobId);
    if (!job) {
        throw new Error("Jobb hittades inte");
    }

    const oldTitle = job.title;
    job.title = newTitle || "";

    // 3. Logga historik
    const history = new HistoryEntry({
        id: `hist-${Date.now()}`,
        tenantId,
        jobId,
        action: "job.renamed",
        payload: { oldTitle, newTitle: job.title }
    });

    await storage.appendHistory(tenantId, history);

    // 4. Spara projekt
    await storage.saveProject(tenantId, project);

    return job;
};
