// ============================================================
// FILE: E:\sm-core\core\pipeline\commands\createJob.js
// PURPOSE: Pipeline command – createJob
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const Job = require("../../domain/job");
const HistoryEntry = require("../../domain/historyEntry");
const storage = require("../../storage/storage");

module.exports = async function createJob({ tenantId, title }) {

    if (!tenantId) {
        throw new Error("createJob: tenantId saknas");
    }

    // 1. Ladda projekt
    const project = await storage.loadProject(tenantId);

    if (!Array.isArray(project.jobs)) {
        project.jobs = [];
    }

    // 2. Generera nytt ID (100% säker)
    const numericIds = project.jobs
        .map(j => j.id)
        .filter(id => typeof id === "string" && /^[0-9]+$/.test(id)) // endast rena siffror
        .map(id => Number(id))
        .filter(n => Number.isInteger(n) && n > 0);

    const nextId = numericIds.length > 0 ? Math.max(...numericIds) + 1 : 10000;

    // 3. Skapa jobb (⭐ C1: completed = false)
    const job = new Job({
        id: String(nextId),
        tenantId,
        title: typeof title === "string" ? title : "",
        completed: false
    });

    project.jobs.push(job);

    // 4. Logga historik
    const history = new HistoryEntry({
        id: `hist-${Date.now()}`,
        tenantId,
        jobId: job.id,
        action: "job.created",
        payload: { title: job.title }
    });

    await storage.appendHistory(tenantId, history);

    // 5. Spara projekt
    await storage.saveProject(tenantId, project);

    return job;
};
