// ============================================================
// FILE: E:\sm-core\core\pipeline\commands\renameFile.js
// PURPOSE: Pipeline command – renameFile
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const HistoryEntry = require("../../domain/historyEntry");
const storage = require("../../storage/storage");
const path = require("path");

module.exports = async function renameFile({ tenantId, jobId, fileId, newName }) {

    if (!tenantId) throw new Error("renameFile: tenantId saknas");
    if (!jobId) throw new Error("renameFile: jobId saknas");
    if (!fileId) throw new Error("renameFile: fileId saknas");
    if (!newName) throw new Error("renameFile: newName saknas");

    const project = await storage.loadProject(tenantId);
    if (!Array.isArray(project.jobs)) project.jobs = [];

    const job = project.jobs.find(j => j.id === jobId);
    if (!job) throw new Error("Jobb hittades inte");

    const slots = ["before", "after", "documents"];
    let file = null;

    // ------------------------------------------------------------
    // Hitta filen i rätt slot
    // ------------------------------------------------------------
    for (const slot of slots) {
        if (!Array.isArray(job[slot])) continue;

        const found = job[slot].find(f => f.id === fileId);
        if (found) {
            file = found;
            break;
        }
    }

    if (!file) throw new Error("Filen hittades inte i jobbet");

    // ------------------------------------------------------------
    // Behåll extension från filename (ID-baserad)
    // ------------------------------------------------------------
    const ext = path.extname(file.filename || file.originalName || "").toLowerCase();

    // ------------------------------------------------------------
    // Uppdatera ENDAST originalName
    // ------------------------------------------------------------
    const oldOriginal = file.originalName;
    const oldFilename = file.filename;

    file.originalName = newName.endsWith(ext) ? newName : newName + ext;

    // filename och filen i raw/ ändras INTE
    // file.filename = oldFilename;

    // ------------------------------------------------------------
    // Historik
    // ------------------------------------------------------------
    const history = new HistoryEntry({
        id: `hist-${Date.now()}`,
        tenantId,
        jobId,
        action: "file.renamed",
        payload: {
            fileId,
            oldOriginal,
            oldFilename,
            newOriginal: file.originalName,
            newFilename: oldFilename // alltid samma
        }
    });

    await storage.appendHistory(tenantId, history);
    await storage.saveProject(tenantId, project);

    return job;
};
