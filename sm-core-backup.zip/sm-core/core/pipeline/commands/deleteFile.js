// ============================================================
// FILE: E:\sm-core\core\pipeline\commands\deleteFile.js
// PURPOSE: Pipeline command – deleteFile
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const fs = require("fs");
const path = require("path");
const HistoryEntry = require("../../domain/historyEntry");
const storage = require("../../storage/storage");

module.exports = async function deleteFile({ tenantId, jobId, fileId }) {
    if (!tenantId) throw new Error("deleteFile: tenantId saknas");
    if (!jobId) throw new Error("deleteFile: jobId saknas");
    if (!fileId) throw new Error("deleteFile: fileId saknas");

    // Ladda projekt
    const project = await storage.loadProject(tenantId);
    const job = project.jobs.find(j => j.id === jobId);

    if (!job) throw new Error("Jobb hittades inte");

    // Normalisera arrays
    job.before = Array.isArray(job.before) ? job.before : [];
    job.after = Array.isArray(job.after) ? job.after : [];
    job.documents = Array.isArray(job.documents) ? job.documents : [];

    // Hitta filen innan vi tar bort den
    const all = [...job.before, ...job.after, ...job.documents];
    const file = all.find(f => f.id === fileId);

    if (!file) {
        throw new Error("Filen hittades inte för delete");
    }

    const filename = file.filename;

    // Ta bort filreferensen
    const remove = arr => arr.filter(f => f.id !== fileId);

    job.before = remove(job.before);
    job.after = remove(job.after);
    job.documents = remove(job.documents);

    // ------------------------------------------------------------
    // Ta bort filen från raw-mappen
    // ------------------------------------------------------------
    if (filename) {
        const rawPath = path.join(
            __dirname,
            "..",
            "..",
            "..",
            "data",
            "tenants",
            tenantId,
            "files",
            "raw",
            filename
        );

        try {
            if (fs.existsSync(rawPath)) {
                fs.unlinkSync(rawPath);
            }
        } catch (err) {
            console.error("Kunde inte ta bort filen från raw:", err);
        }
    }

    // ------------------------------------------------------------
    // Logga historik
    // ------------------------------------------------------------
    const history = new HistoryEntry({
        id: `hist-${Date.now()}`,
        tenantId,
        jobId,
        action: "file.deleted",
        payload: { fileId, filename }
    });

    await storage.appendHistory(tenantId, history);

    // Spara projekt
    await storage.saveProject(tenantId, project);

    return job;
};
