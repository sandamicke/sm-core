// ============================================================
// FILE: E:\sm-core\core\storage\storage.js
// PURPOSE: Storage layer (tenant-based, internal data root)
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const fs = require("fs");
const path = require("path");
const { tenantPaths } = require("../../config/paths");

// Säker katalogskapare
function ensureDir(dir) {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
}

module.exports = {

    // ------------------------------------------------------------
    // Ladda projekt.json för en tenant
    // ------------------------------------------------------------
    async loadProject(tenantId) {
        const paths = tenantPaths(tenantId);

        ensureDir(paths.base);

        // Skapa fil om den saknas
        if (!fs.existsSync(paths.projectFile)) {
            const empty = {
                created: Date.now(),
                jobs: []
            };

            await fs.promises.writeFile(
                paths.projectFile,
                JSON.stringify(empty, null, 2),
                "utf8"
            );

            return empty;
        }

        // Läs projektfil
        let raw;
        try {
            raw = await fs.promises.readFile(paths.projectFile, "utf8");
        } catch (err) {
            console.error("Fel vid läsning av projektfil:", err);
            return { jobs: [] };
        }

        try {
            const parsed = JSON.parse(raw);

            // Defensiv normalisering
            if (!Array.isArray(parsed.jobs)) {
                parsed.jobs = [];
            }

            if (!parsed.created) {
                parsed.created = Date.now();
            }

            return parsed;

        } catch (err) {
            console.error("Fel vid JSON-parse av projektfil:", err);
            return { jobs: [] };
        }
    },

    // ------------------------------------------------------------
    // Spara projekt.json
    // ------------------------------------------------------------
    async saveProject(tenantId, project) {
        const paths = tenantPaths(tenantId);

        ensureDir(paths.base);

        if (!Array.isArray(project.jobs)) {
            project.jobs = [];
        }

        if (!project.created) {
            project.created = Date.now();
        }

        await fs.promises.writeFile(
            paths.projectFile,
            JSON.stringify(project, null, 2),
            "utf8"
        );
    },

    // ------------------------------------------------------------
    // Lägg till historikpost
    // ------------------------------------------------------------
    async appendHistory(tenantId, historyEntry) {
        const paths = tenantPaths(tenantId);

        ensureDir(paths.historyDir);

        const file = path.join(paths.historyDir, `${historyEntry.id}.json`);

        await fs.promises.writeFile(
            file,
            JSON.stringify(historyEntry, null, 2),
            "utf8"
        );
    }
};
