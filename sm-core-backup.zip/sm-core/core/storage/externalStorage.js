// ============================================================
// FILE: E:\sm-core\core\storage\externalStorage.js
// PURPOSE: Raw file storage (internal data root)
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { tenantPaths } = require("../../config/paths");
const FileRef = require("../domain/fileRef");

// Säker mappskapare
function ensureDir(dir) {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
}

// Skapa SHA256-checksum
function sha256(buffer) {
    return crypto.createHash("sha256").update(buffer).digest("hex");
}

module.exports = {
    // ------------------------------------------------------------
    // Spara råfil och returnera FileRef
    // ------------------------------------------------------------
    async saveRawFile({ tenantId, buffer, originalName, mimeType }) {

        if (!tenantId) throw new Error("saveRawFile: tenantId saknas");
        if (!buffer) throw new Error("saveRawFile: buffer saknas");
        if (!originalName) throw new Error("saveRawFile: originalName saknas");

        const paths = tenantPaths(tenantId);

        // Konvertera originalnamn från latin1 → UTF-8
        const originalNameUtf8 = Buffer.from(originalName, "latin1").toString("utf8");

        // Råfiler hamnar här
        const rawDir = paths.rawDir;   // <- Detta pekar på .../files/raw
        ensureDir(rawDir);

        // Skapa unikt fil-ID
        const fileId = "file-" + crypto.randomBytes(8).toString("hex");

        // Behåll original extension
        const ext = path.extname(originalNameUtf8) || "";

        // Filnamn på disk
        const filename = `${fileId}${ext}`;
        const fullPath = path.join(rawDir, filename);

        // Skriv råfil (async)
        await fs.promises.writeFile(fullPath, buffer);

        // Skapa FileRef – KORREKT URL
        const fileRef = new FileRef({
            id: fileId,
            tenantId,
            url: `/files/raw/${tenantId}/${filename}`,   // ⭐ ENDA KORREKTA URL:en
            type: mimeType || "application/octet-stream",
            size: buffer.length,
            checksum: sha256(buffer),
            originalName: originalNameUtf8,
            created: Date.now()
        });

        return fileRef;
    }
};
