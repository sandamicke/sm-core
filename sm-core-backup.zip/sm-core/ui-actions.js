// ============================================================
// FILE: E:\sm-core\ui-actions.js
// PURPOSE: Rename, Delete, Download, Rename Job (Modul 2) + C2 Completed Toggle
// PROJECT: SM Core v0003
// OWNER: Sandamicke
// NOTE: Header är grep-friendly och måste förbli intakt.
// ============================================================

// ------------------------------------------------------------
// Hjälpfunktion: Bygg korrekt URL för fil
// ------------------------------------------------------------
function buildFileUrl(file) {
    if (!file || !file.filename) return null;
    return `/files/raw/${file.filename}`;
}

// ------------------------------------------------------------
// Hjälpfunktion: Ladda ner fil och öppna lokalt
// ------------------------------------------------------------
function downloadAndOpen(file) {
    const url = buildFileUrl(file);
    if (!url) return;

    fetch(url)
        .then(res => res.blob())
        .then(blob => {
            const tempUrl = URL.createObjectURL(blob);

            const a = document.createElement("a");
            a.href = tempUrl;
            a.download = file.originalName || file.name || "dokument";
            document.body.appendChild(a);
            a.click();
            a.remove();

            setTimeout(() => URL.revokeObjectURL(tempUrl), 5000);
        })
        .catch(err => {
            console.error("Nedladdningsfel:", err);
            alert("Kunde inte ladda ner filen.");
        });
}

// ------------------------------------------------------------
// Dummy-funktioner för Word/Excel
// ------------------------------------------------------------
function openInWord(file) {
    downloadAndOpen(file);
}

function openInExcel(file) {
    downloadAndOpen(file);
}

// ------------------------------------------------------------
// Byt namn på fil
// ------------------------------------------------------------
async function renameFile(jobId, fileId, currentName) {
    try {
        const newName = window.prompt("Nytt filnamn:", currentName);
        if (!newName || newName.trim() === "" || newName === currentName) return;

        const payload = {
            tenantId: TENANT,
            jobId,
            fileId,
            newName: newName.trim()
        };

        const res = await fetch(window.location.origin + "/api/files/rename", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await res.json();

        if (data.success && data.job) {
            currentJob = data.job;

            renderSection("before");
            renderSection("after");
            renderSection("documents");
        }
    } catch (err) {
        console.error("Fel vid renameFile:", err);
    }
}

// ------------------------------------------------------------
// Ta bort fil
// ------------------------------------------------------------
async function deleteFile(jobId, fileId, fileName) {
    try {
        const ok = window.confirm(`Vill du verkligen ta bort filen:\n\n${fileName}`);
        if (!ok) return;

        const payload = {
            tenantId: TENANT,
            jobId,
            fileId
        };

        const res = await fetch(window.location.origin + "/api/files/delete", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await res.json();

        if (data.success && data.job) {
            currentJob = data.job;

            renderSection("before");
            renderSection("after");
            renderSection("documents");
        }
    } catch (err) {
        console.error("Fel vid deleteFile:", err);
    }
}

// ------------------------------------------------------------
// Byt namn på jobb
// ------------------------------------------------------------
async function renameJobUI(jobId) {
    try {
        const job = jobs.find(j => j.id === jobId);
        if (!job) return alert("Jobb hittades inte");

        const newTitle = window.prompt("Nytt jobbnamn:", job.title);
        if (!newTitle || newTitle.trim() === "" || newTitle === job.title) return;

        const payload = {
            tenantId: TENANT,
            jobId,
            newTitle: newTitle.trim()
        };

        const res = await fetch(window.location.origin + "/api/jobs/rename", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await res.json();

        if (data.error) {
            alert("Kunde inte byta namn på jobbet: " + data.error);
            return;
        }

        job.title = newTitle.trim();

        loadJobs();

    } catch (err) {
        console.error("Fel vid renameJobUI:", err);
    }
}

// ------------------------------------------------------------
// Ta bort jobb
// ------------------------------------------------------------
async function deleteJob(jobId) {
    try {
        const ok = window.confirm(`Vill du verkligen ta bort jobbet:\n\n${jobId}`);
        if (!ok) return;

        const payload = {
            tenantId: TENANT,
            jobId
        };

        const res = await fetch(window.location.origin + "/api/jobs/delete", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await res.json();

        if (data.success) {
            loadJobs();
        } else {
            alert("Kunde inte ta bort jobbet: " + data.error);
        }
    } catch (err) {
        console.error("Fel vid deleteJob:", err);
    }
}

// ============================================================
// C2: Markera jobb som klart / ångra klart
// ============================================================
async function toggleComplete(jobId, newState) {
    try {
        const payload = {
            tenantId: TENANT,
            jobId,
            completed: newState
        };

        const res = await fetch(window.location.origin + "/api/jobs/complete", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await res.json();

        if (!data.success) {
            alert("Kunde inte ändra status på jobbet.");
            return;
        }

        // ⭐ DEV FIX: Ladda om och rendera om jobblistan
        await loadJobs();
        renderJobLists(jobs);

    } catch (err) {
        console.error("Fel vid toggleComplete:", err);
    }
}
